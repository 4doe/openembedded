#!/bin/sh
#
# this script running after factory reset automatically
# Do not change this script. if you change something, we can not support it.
#

. /etc/profile >/dev/null 2>&1

FACTORY_ALL=0
if [ "$1" == "all" ]; then
	echo " -- factory reset all"	
	FACTORY_ALL=1
else
	echo " -- factory reset"	
fi

/usr/bin/showiframe /usr/share/bootlogo.mvi

#
# tool functions
#

wrap_function_for_msg()
{
	echo -n $1
	$1
	if [ $? == 0 ];then
		echo " ... Done"
	else
		echo " ... Failed"
	fi
}

#
# functions
#

reset_cam_keys()
{
	rm -f /var/keys/*.Key
	rm -f /var/keys/Keylist.txt
}

#@ NOTE : 
#@ except mgcamd
#@ "enigma2-plugin-softcams.config-cccam_1.0-r0_mipsel.ipk" # IPKG_FACTORY_ALL_ONLY
#@ "enigma2-plugin-softcams.config-mgcamd_1.30d-r0_mipsel.ipki" # IPKG_FILE_FACTORY_ALL_ONLY


reset_opkg()
{
	IPKG_FACTORY_ALL_ONLY="enigma2-plugin-softcams.config-cccam 
	enigma2-plugin-softcams.config-newcs"
	IPKG_FILE_FACTORY_ALL_ONLY="enigma2-plugin-softcams.config-cccam_1.0-r0_mipsel.ipk
	enigma2-plugin-softcams.config-newcs_1.0-r0_mipsel.ipk"

	IPKG_LIST_FACTORY=/usr/lib/opkg/opkg_list_factory
	IPKG_LIST_INSTALLED=/tmp/.opkg_list_installed

# remove package not in factory list. only work with internet connection
	opkg list-installed | awk '{print $1}' > $IPKG_LIST_INSTALLED
	while read line
	do
		grep $line $IPKG_LIST_FACTORY > /dev/null
		if [ $? == 1 ]; then
			echo " -- remove $line"
			opkg remove --force-depends $line
		fi
	done < $IPKG_LIST_INSTALLED
	rm $IPKG_LIST_INSTALLED

# force to remove some pkg in factory list for full factory reset
	if [ $FACTORY_ALL -eq 1 ]; then
		for pkg in $IPKG_FACTORY_ALL_ONLY
		do
			echo " -- full remove $pkg"
			opkg remove $pkg
		done

		for file in $IPKG_FILE_FACTORY_ALL_ONLY
		do
			echo " -- full install $file"
			opkg install /tmp/$file
		done
	fi

# if connected to internet, belows are not necessary. But how install other missing packages if not connected internet?
	if [ "`opkg list-installed | grep enigma2-plugin-softcams-cccam221`" == "" ]; then
		opkg install /tmp/enigma2-plugin-softcams-cccam221_2.2.1-r0_mipsel.ipk
	fi
	if [ "`opkg list-installed | grep enigma2-plugin-softcams.config-mgcamd`" == "" ]; then
		opkg install /tmp/enigma2-plugin-softcams.config-mgcamd_1.30d-r5_mipsel.ipk
	fi

# install package in factory list. only work with internet connection
	opkg list-installed | awk '{print $1}' > $IPKG_LIST_INSTALLED
	while read line
	do
		grep $line $IPKG_LIST_INSTALLED > /dev/null
		if [ $? == 1 ]; then
			echo " -- install $line"
			opkg install $line
		fi
	done < $IPKG_LIST_FACTORY
	rm $IPKG_LIST_INSTALLED

	rm -f /usr/lib/opkg/iq-party
}

reset_password()
{
	if [ $FACTORY_ALL == 1 ]; then
		(echo "";sleep 1;echo "";) | passwd
	fi
}

reset_gw_settings()
{
	rm -f /etc/default_gw
}

reset_enigma2_settings()
{
	rm -rf /etc/enigma2
	mkdir /etc/enigma2
	cp -R /usr/share/enigma2/defaults/Dream /etc/enigma2/
}

reset_default_install()
{
	mv /etc/.def_inst /etc/def_inst
}

reset_localcs_info()
{
	if [ -e /etc/.serverinfo_cccam ] ; then
		rm -f /etc/.serverinfo_cccam
		rm -f /var/keys/.serverinfo_mgcamd
		rm -f /var/.cs_pub_disable
	fi
}

reset_cron()
{
	rm -rf /etc/cron/*
}

reset_scripts()
{
	if [ -d /usr/scripts ]; then
		rm -rf /usr/scripts/*
	fi
}

wrap_function_for_msg reset_cam_keys
wrap_function_for_msg reset_opkg
wrap_function_for_msg reset_password
wrap_function_for_msg reset_gw_settings
wrap_function_for_msg reset_enigma2_settings
#wrap_function_for_msg reset_default_install
wrap_function_for_msg reset_localcs_info
wrap_function_for_msg reset_cron
wrap_function_for_msg reset_scripts

echo
